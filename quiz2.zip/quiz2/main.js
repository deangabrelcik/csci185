function changeBackground() {
    console.log(`Change the background color to blue`); 
    document.querySelector("s1").style.backgroundColor="blue";
}


function goodbye() {
    console.log(`Change the message to goodbye`); 
    document.querySelector("message");
}


function showDog() {
console.log(`change the photo to a dog`);
document.querySelector("animal");

}
